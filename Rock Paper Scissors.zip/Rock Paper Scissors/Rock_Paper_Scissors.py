from tkinter import *
import random
from PIL import ImageTk, Image

def main(choice):
    # set computers choices to random
    computer_choices = random.choice(['Rock', 'Paper', 'Scissors'])
    computer_result.set(computer_choices)

    # set my choices to choice
    my_choices.set(choice)

    # if statement to determine winner
    if my_choices.get() == computer_choices:
        winner = "It's a Tie!"
    elif my_choices.get() == 'Rock':
        if computer_choices == 'Paper':
            winner = 'Computer Wins!'
        else:
            winner = 'You Win!'
    elif my_choices.get() == 'Paper':
        if computer_choices == 'Scissors':
            winner = 'Computer Wins!'
        else:
            winner = 'You Win!'
    elif my_choices.get() == 'Scissors':
        if computer_choices == 'Rock':
            winner = 'Computer Wins!'
        else:
            winner = 'You Win!'
    else:
        winner = 'Invalid Choice!'

    my_result.set(f'Your choice is: {my_choices.get()}')
    computer_result.set(f'Computer choice is: {computer_choices}')
    winner_result_label.config(text=f'Winner: {winner}')

# create window
window = Tk()
window.title('Rock Paper Scissors')
window.configure(bg='beige')
window.geometry('500x575')

# convert choices and results to string var
my_choices = StringVar()
my_result = StringVar()
computer_result = StringVar()

# title label and gird
title_label = Label(window, text='Rock Paper Scissors :)', bg='beige', font=('comic sans', 20, 'bold'))
title_label.grid(row=0, column=0, columnspan=3, ipadx=10, ipady=10)

# image label and grid
img = Image.open('rock paper scissors.jpg')
img = img.resize((450, 200), Image.ANTIALIAS)
photo = ImageTk.PhotoImage(img)
img_label = Label(window, image=photo)
img_label.grid(row=2, column=0, padx=20, pady=10)
img_label.image = photo

# buttons and grid location
rock_button = Button(window, text='Rock', command=lambda: main('Rock') , bg='brown', width=10, justify='center', anchor='center', font=('comic sans', 10))
rock_button.grid(row=3, column=0, columnspan=3, ipadx=10, ipady=10, padx=200, pady=0, sticky='nsew')

paper_button = Button(window, text='Paper', command=lambda: main('Paper'), bg='white', width=10, justify='center', anchor='center', font=('comic sans', 10))
paper_button.grid(row=4, column=0, columnspan=3, ipadx=10, ipady=10, padx=200, pady=0, sticky='nsew')

scissors_button = Button(window, text='Scissors', command=lambda: main('Scissors'), bg='blue', width=10, justify='center', anchor='center', font=('comic sans', 10))
scissors_button.grid(row=5, column=0, columnspan=3, ipadx=10, ipady=10, padx=200, pady=0, sticky='nsew')

# result labels
my_result_label = Label(window, text='Your choice is: ', textvariable=my_result, bg='beige', font=('comic sans', 15))
my_result_label.grid(row=6, column=0, ipadx=10, ipady=10, padx=0, sticky='w')

computer_result_label = Label(window, text='Computer choice is: ', textvariable=computer_result, bg='beige', font=('comic sans', 15))
computer_result_label.grid(row=7, column=0, ipadx=10, ipady=10, padx=0, sticky='w')

winner_result_label = Label(window, bg='beige', font=('comic sans', 15))
winner_result_label.grid(row=8, column=0, ipadx=10, ipady=10, padx=0, sticky='w')

# run main loop
window.mainloop()